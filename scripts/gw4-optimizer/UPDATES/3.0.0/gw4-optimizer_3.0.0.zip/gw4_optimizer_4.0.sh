#!/usr/bin/env bash
# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║  Galaxy Watch 4 Pro Optimizer Suite  v3.0                                 ║
# ║  Samsung SM-R870 · Exynos W920 · One UI 8.0 / WearOS 6.0 / Android 16    ║
# ║                                                                            ║
# ║  Autor: SecFerro Division · oparty na raportach poszkodowanych użytkowników║
# ║                                                                            ║
# ║  Naprawia:                                                                 ║
# ║    · Lagi i spadki klatek po aktualizacji One UI 8.0                      ║
# ║    · Lagujące przejścia AOD → ekran aktywny                               ║
# ║    · Drenaż baterii przez niezoptymalizowane usługi One UI                ║
# ║    · Nieskompilowane profile ART (nowe aplikacje)                         ║
# ║    · Nadmiar procesów w tle (phantom procs)                               ║
# ║                                                                            ║
# ║  Wymaga: bash 4+, adb w PATH, zegarek z włączonym ADB over Wi-Fi         ║
# ╚══════════════════════════════════════════════════════════════════════════════╝
#
# SPDX-License-Identifier: MIT
#
# Instrukcja szybkiego startu (patrz też funkcja show_setup_guide):
#   1. Zegarek: Ustawienia → System → Informacje → O oprogramowaniu
#              → kliknij 7x "Numer kompilacji"  → Opcje programisty włączone
#   2. Zegarek: Opcje programisty → Debugowanie przez Wi-Fi → Włącz
#              → Zanotuj IP:PORT wyświetlone na ekranie
#   3. PC:     bash gw4_optimizer.sh

set -euo pipefail

# ═══════════════════════════════════════════════════════════════════════════════
# §0  STAŁE
# ═══════════════════════════════════════════════════════════════════════════════

readonly VERSION="3.0.0"
readonly SCRIPT_NAME="GW4 Pro Optimizer Suite"
readonly DEFAULT_PORT="5555"
readonly ADB_RETRY=4
readonly ADB_TIMEOUT=10
readonly ADB_WAKE_RETRY=3           # zegarki uśpiają ADB — retry po wybudzeniu
readonly LOG_DIR="${HOME}/.gw4_optimizer"
readonly LOG_FILE="${LOG_DIR}/session_$(date +%Y%m%d_%H%M%S).log"
readonly BACKUP_FILE="${LOG_DIR}/settings_backup_$(date +%Y%m%d_%H%M%S).txt"

# Exynos W920 — zweryfikowane stałe sprzętowe
readonly W920_CORTEX="cortex-a55"    # rdzenie CPU (dual A55 @ 1.18GHz)
readonly W920_GPU="Mali-G68"         # GPU (2-core)
readonly W920_RAM_MB=1500            # 1.5GB LPDDR4X

# ═══════════════════════════════════════════════════════════════════════════════
# §1  KOLORY I LOGGING
# ═══════════════════════════════════════════════════════════════════════════════

# Kolory z fallbackiem dla środowisk bez tty
if [[ -t 1 ]] && tput colors &>/dev/null && [[ $(tput colors) -ge 8 ]]; then
    C0='\033[0m'      BOLD='\033[1m'    DIM='\033[2m'
    GREEN='\033[32m'  RED='\033[31m'    YELLOW='\033[33m'
    CYAN='\033[36m'   MAG='\033[35m'    BLUE='\033[34m'
    WHITE='\033[97m'
else
    C0='' BOLD='' DIM='' GREEN='' RED='' YELLOW='' CYAN='' MAG='' BLUE='' WHITE=''
fi

_ts()   { date +"%H:%M:%S"; }
ok()    { printf "${GREEN}  ✓  ${C0}${BOLD}%s${C0}\n" "$*"; echo "$(_ts) [OK   ] $*" >> "${LOG_FILE}"; }
err()   { printf "${RED}  ✗  ${C0}${BOLD}%s${C0}\n" "$*" >&2; echo "$(_ts) [ERROR] $*" >> "${LOG_FILE}"; }
warn()  { printf "${YELLOW}  ⚠  ${C0}%s${C0}\n" "$*"; echo "$(_ts) [WARN ] $*" >> "${LOG_FILE}"; }
info()  { printf "${CYAN}  →  ${C0}%s\n" "$*"; echo "$(_ts) [INFO ] $*" >> "${LOG_FILE}"; }
fix()   { printf "${MAG}  ⚙  ${C0}%s\n" "$*"; echo "$(_ts) [FIX  ] $*" >> "${LOG_FILE}"; }
hdr()   { printf "\n${CYAN}${BOLD}  ══ %s ══${C0}\n" "$*"; }
fatal() { err "FATAL: $*"; exit 1; }

_progress() {
    local label="$1" pct="$2"
    local filled=$(( pct * 25 / 100 ))
    local bar=""
    for ((i=0;i<25;i++)); do [[ $i -lt $filled ]] && bar+="█" || bar+="░"; done
    printf "\r  ${CYAN}%-28s${C0} [${GREEN}%s${C0}] %3d%%" "$label" "$bar" "$pct"
}

# ═══════════════════════════════════════════════════════════════════════════════
# §2  INIT
# ═══════════════════════════════════════════════════════════════════════════════

DEVICE=""           # IP:PORT aktywnego urządzenia
DEVICE_SDK=""       # Android SDK (np. 35 dla Android 15, 36 dla Android 16)
DEVICE_MODEL=""
DEVICE_FW=""
BACKUP_DONE=false

_init() {
    mkdir -p "${LOG_DIR}"
    echo "=== ${SCRIPT_NAME} v${VERSION} — $(date) ===" >> "${LOG_FILE}"
    command -v adb &>/dev/null || fatal "adb nie znaleziony w PATH. Zainstaluj Android Platform Tools."
}

# ═══════════════════════════════════════════════════════════════════════════════
# §3  ZARZĄDZANIE POŁĄCZENIEM ADB
# ═══════════════════════════════════════════════════════════════════════════════

_adb()  { timeout "${ADB_TIMEOUT}" adb -s "${DEVICE}" "$@" 2>/dev/null; }
_sh()   { _adb shell "$@" 2>/dev/null | tr -d '\r'; }

# ADB shell z retry — zegarki często tracą połączenie przy uśpieniu
_sh_retry() {
    local cmd="$*"
    local attempt result
    for ((attempt=1; attempt<=ADB_WAKE_RETRY; attempt++)); do
        result="$(timeout "${ADB_TIMEOUT}" adb -s "${DEVICE}" shell "${cmd}" 2>/dev/null | tr -d '\r')" \
            && { printf '%s' "${result}"; return 0; }
        [[ $attempt -lt $ADB_WAKE_RETRY ]] && {
            warn "Zegarek nie odpowiada (próba ${attempt}/${ADB_WAKE_RETRY}) — poczekaj..."
            sleep 2
            # Obudź zegarek ekranem
            adb -s "${DEVICE}" shell input keyevent KEYCODE_WAKEUP 2>/dev/null || true
            sleep 1
        }
    done
    err "ADB shell timeout po ${ADB_WAKE_RETRY} próbach: ${cmd}"
    return 1
}

_adb_connect() {
    local target="$1"
    info "Łączenie z ${target}..."
    adb disconnect &>/dev/null || true
    sleep 0.5

    local attempt state
    for ((attempt=1; attempt<=ADB_RETRY; attempt++)); do
        adb connect "${target}" &>/dev/null || true
        sleep 1.5
        state="$(adb -s "${target}" get-state 2>/dev/null || echo 'offline')"
        case "${state}" in
            device)
                DEVICE="${target}"
                ok "Połączono: ${target}"
                return 0
                ;;
            unauthorized)
                err "Urządzenie nieautoryzowane — zatwierdź odcisk RSA na zegarku"
                err "Sprawdź: pojawił się komunikat \"Czy zezwolić na debugowanie USB\"?"
                return 1
                ;;
            offline)
                [[ $attempt -lt $ADB_RETRY ]] && {
                    info "Urządzenie offline, próba ${attempt}/${ADB_RETRY}..."
                    # Spróbuj obudzić zegarek przed kolejną próbą
                    adb -s "${target}" shell input keyevent KEYCODE_WAKEUP 2>/dev/null || true
                    sleep 2
                }
                ;;
        esac
    done

    err "Nie można połączyć z ${target} po ${ADB_RETRY} próbach"
    err "Sprawdź: czy zegarek i PC są w tej samej sieci Wi-Fi?"
    err "Sprawdź: Opcje programisty → Debugowanie przez Wi-Fi → aktywne?"
    return 1
}

_ask_ip() {
    printf "\n${CYAN}${BOLD}  Podaj IP zegarka (IP:PORT lub samo IP)${C0}\n"
    printf "  ${DIM}Format: 192.168.1.X lub 192.168.1.X:5555${C0}\n"
    read -r -p "  > " user_input
    local ip="${user_input}"
    # Dodaj domyślny port jeśli brak
    [[ "${ip}" != *:* ]] && ip="${ip}:${DEFAULT_PORT}"
    printf '%s' "${ip}"
}

_detect_device() {
    hdr "Wykrywanie urządzenia"

    # Próba auto-detect z listy podłączonych urządzeń
    local detected
    detected="$(adb devices 2>/dev/null | awk 'NR>1 && $2=="device" && $1 ~ /^[0-9]/{print $1}' | head -1)"
    if [[ -n "${detected}" ]]; then
        info "Wykryto podłączone urządzenie: ${detected}"
        DEVICE="${detected}"
    else
        local ip
        ip="$(_ask_ip)"
        _adb_connect "${ip}" || return 1
    fi

    # Odczyt parametrów urządzenia
    DEVICE_MODEL="$(_sh_retry "getprop ro.product.model")"
    DEVICE_FW="$(_sh_retry "getprop ro.build.display.id")"
    DEVICE_SDK="$(_sh_retry "getprop ro.build.version.sdk")"
    local android_ver; android_ver="$(_sh_retry "getprop ro.build.version.release")"
    local hw; hw="$(_sh_retry "getprop ro.hardware")"

    printf "\n"
    printf "  ${WHITE}%-22s${C0} %s\n" "Model:"    "${DEVICE_MODEL:-?}"
    printf "  ${WHITE}%-22s${C0} %s\n" "Firmware:" "${DEVICE_FW:-?}"
    printf "  ${WHITE}%-22s${C0} Android %s (SDK %s)\n" "System:" \
           "${android_ver:-?}" "${DEVICE_SDK:-?}"
    printf "  ${WHITE}%-22s${C0} %s\n" "Hardware:" "${hw:-?}"
    printf "\n"

    # Sprawdź czy to Galaxy Watch (SM-R8xx)
    if [[ "${DEVICE_MODEL:-}" =~ ^SM-R8 ]]; then
        ok "Galaxy Watch zidentyfikowany: ${DEVICE_MODEL}"
    else
        warn "Nierozpoznany model: ${DEVICE_MODEL:-unknown}"
        warn "Skrypt zoptymalizowany dla SM-R870/SM-R875/SM-R895 (Galaxy Watch 4)"
        read -r -p "  Kontynuować mimo to? [t/N] " cont
        [[ "${cont,,}" != "t" ]] && { info "Anulowano."; exit 0; }
    fi

    # Ostrzeżenie dla Android < 12 lub > 16
    local sdk="${DEVICE_SDK:-0}"
    if [[ "${sdk}" -lt 31 ]]; then
        warn "SDK ${sdk} — skrypt wymaga Android 12+ (SDK 31+)"
    elif [[ "${sdk}" -gt 36 ]]; then
        warn "SDK ${sdk} — wersja Android nowsza niż testowana (36/Android 16)"
    fi
}

# ═══════════════════════════════════════════════════════════════════════════════
# §4  BACKUP USTAWIEŃ
# ═══════════════════════════════════════════════════════════════════════════════

_backup_settings() {
    [[ "${BACKUP_DONE}" == "true" ]] && return 0
    hdr "Backup ustawień"

    {
        echo "# GW4 Optimizer — backup $(date)"
        echo "# Urządzenie: ${DEVICE_MODEL} | FW: ${DEVICE_FW}"
        echo ""
        for key in \
            "global window_animation_scale" \
            "global transition_animation_scale" \
            "global animator_duration_scale" \
            "secure doze_always_on" \
            "global monitor_phantom_procs" \
            "global debug_app_ops_mode" \
            "global high_priority_render_thread" \
            "global always_finish_activities" \
            "global background_process_limit" \
            "system screen_off_timeout"; do
            local ns="${key%% *}"
            local k="${key##* }"
            local val; val="$(_sh_retry "settings get ${ns} ${k}")"
            echo "RESTORE:${ns}:${k}=${val}"
        done
    } > "${BACKUP_FILE}"

    BACKUP_DONE=true
    ok "Backup zapisany: ${BACKUP_FILE}"
}

# ═══════════════════════════════════════════════════════════════════════════════
# §5  FIX 1: ANIMACJE — najszybszy efekt, zero ryzyka
# ═══════════════════════════════════════════════════════════════════════════════

_fix_animations() {
    hdr "Fix 1: Optymalizacja animacji"
    _backup_settings

    printf "\n"
    printf "  ${YELLOW}Wybierz tryb animacji:${C0}\n"
    printf "  ${CYAN}1${C0}) Turbo   — 0.5x (widoczne animacje, dużo szybsze)\n"
    printf "  ${CYAN}2${C0}) Wyłącz  — 0.0x (brak animacji, najszybszy)\n"
    printf "  ${CYAN}3${C0}) Przywróć — 1.0x (OEM default)\n"
    printf "  ${CYAN}0${C0}) Anuluj\n\n"
    read -r -p "  > " choice

    local scale
    case "${choice}" in
        1) scale="0.5" ;;
        2) scale="0.0" ;;
        3) scale="1.0" ;;
        0) return ;;
        *) warn "Nieznana opcja"; return ;;
    esac

    _progress "Animacje..." 0
    _sh_retry "settings put global window_animation_scale ${scale}"     && _progress "Animacje..." 33
    _sh_retry "settings put global transition_animation_scale ${scale}" && _progress "Animacje..." 66
    _sh_retry "settings put global animator_duration_scale ${scale}"    && _progress "Animacje..." 100
    printf "\n"

    ok "Animacje ustawione na ${scale}x"
    info "Efekt widoczny natychmiast — bez restartu"
}

# ═══════════════════════════════════════════════════════════════════════════════
# §6  FIX 2: AOD (Always-On Display) — główny sprawca lagów po One UI 8.0
# ═══════════════════════════════════════════════════════════════════════════════
#
#  RAPORT UŻYTKOWNIKÓW: przejście AOD → aktywny ekran laguje ~300-800ms
#  PRZYCZYNA: One UI 8.0 dodał nowe warstwy animacji w SurfaceFlinger
#  ROZWIĄZANIE: albo wyłącz AOD, albo zmień interwał odświeżania AOD
#

_fix_aod() {
    hdr "Fix 2: Always-On Display (AOD)"
    _backup_settings

    # Odczyt aktualnego stanu
    local current; current="$(_sh_retry "settings get secure doze_always_on")"
    info "Aktualny stan AOD: ${current:-null} (1=włączone, 0=wyłączone)"

    printf "\n"
    printf "  ${YELLOW}Wybierz akcję AOD:${C0}\n"
    printf "  ${CYAN}1${C0}) Wyłącz AOD          — eliminuje problem przejścia (zalecane)\n"
    printf "  ${CYAN}2${C0}) Włącz AOD            — przywróć\n"
    printf "  ${CYAN}3${C0}) Tryb Low-Power AOD   — zmniejsz częstotliwość odświeżania AOD\n"
    printf "  ${CYAN}0${C0}) Anuluj\n\n"
    read -r -p "  > " choice

    case "${choice}" in
        1)
            _sh_retry "settings put secure doze_always_on 0"
            # Wyłącz też ambient display (doze)
            _sh_retry "settings put secure doze_enabled 0" || true
            ok "AOD wyłączone — lagi przejścia powinny zniknąć"
            warn "Pamiętaj: AOD pomaga w odczycie godziny bez wybudzania"
            ;;
        2)
            _sh_retry "settings put secure doze_always_on 1"
            _sh_retry "settings put secure doze_enabled 1" || true
            ok "AOD włączone"
            ;;
        3)
            # Tryb Low-Power: rzadsze odświeżanie AOD = mniej pracy SurfaceFlinger
            _sh_retry "settings put secure doze_always_on 1"
            # Obniż jaśność AOD do minimum (mniej GPU)
            _sh_retry "settings put system screen_brightness_mode 0" || true
            # One UI 8.0: prop dla częstotliwości AOD
            _sh_retry "setprop persist.sys.sf.aod_refresh_rate 1" || true
            ok "Tryb Low-Power AOD aktywny"
            info "Jeśli lagi pozostają — użyj opcji 1 (wyłącz AOD)"
            ;;
        0) return ;;
        *) warn "Nieznana opcja" ;;
    esac
}

# ═══════════════════════════════════════════════════════════════════════════════
# §7  FIX 3: SURFACEFLINGER — optymalizacja renderowania
# ═══════════════════════════════════════════════════════════════════════════════
#
#  WAŻNE: SurfaceFlinger 1008 i32 1 = wyłączenie HW Overlays
#  Na W920 z Mali-G68 to POGARSZA wydajność (GPU musi składać wszystkie warstwy)
#  Prawidłowe podejście: optymalizuj phase offset i vsync, NIE wyłączaj overlays
#

_fix_surfaceflinger() {
    hdr "Fix 3: SurfaceFlinger (renderowanie)"
    _backup_settings

    printf "\n"
    printf "  ${YELLOW}Wybierz optymalizację SF:${C0}\n"
    printf "  ${CYAN}1${C0}) Optymalizacja vsync phase offset (${GREEN}zalecane${C0})\n"
    printf "      Redukuje opóźnienie między klatkami na A55\n"
    printf "  ${CYAN}2${C0}) Wyłącz HW Overlays (Force GPU) — ${RED}NIE ZALECANE na W920${C0}\n"
    printf "      Mali-G68 jest wolniejszy bez overlays. Użyj tylko do testów!\n"
    printf "  ${CYAN}3${C0}) Przywróć HW Overlays (jeśli włączyłeś opcję 2)\n"
    printf "  ${CYAN}4${C0}) High-Priority Render Thread\n"
    printf "  ${CYAN}0${C0}) Anuluj\n\n"
    read -r -p "  > " choice

    case "${choice}" in
        1)
            # Phase offset dla A55 @ 1.18GHz — opóźnienie 8.5ms (120Hz refresh)
            _sh_retry "setprop debug.sf.phase_offset_ns 1000000"       || true
            _sh_retry "setprop debug.sf.early_phase_offset_ns 500000"  || true
            _sh_retry "setprop debug.app.phase_offset_ns 1000000"      || true
            # Wyłącz HWUI profiling (zbiera dane i spowalnia)
            _sh_retry "setprop debug.hwui.profile false"               || true
            _sh_retry "setprop debug.hwui.overdraw false"              || true
            ok "SurfaceFlinger phase offset zoptymalizowany dla A55"
            info "Efekt: redukcja frame latency o ~10-20ms"
            ;;
        2)
            warn "Wyłączam HW Overlays — mali GPU przejmuje całą kompozycję"
            warn "Na W920 może to ZWIĘKSZYĆ lagi. Testuj przez 5 min."
            _sh "service call SurfaceFlinger 1008 i32 1" || true
            ok "HW Overlays wyłączone (Force GPU)"
            info "Przywróć opcją 3 jeśli gorzej"
            ;;
        3)
            _sh "service call SurfaceFlinger 1008 i32 0" || true
            ok "HW Overlays przywrócone"
            ;;
        4)
            _sh_retry "settings put global high_priority_render_thread 1" || true
            ok "High-priority render thread włączony"
            ;;
        0) return ;;
        *) warn "Nieznana opcja" ;;
    esac
}

# ═══════════════════════════════════════════════════════════════════════════════
# §8  FIX 4: PAMIĘĆ I PROCESY TŁA
# ═══════════════════════════════════════════════════════════════════════════════

_fix_memory() {
    hdr "Fix 4: Pamięć i procesy tła"
    _backup_settings

    # Odczyt RAM
    local meminfo; meminfo="$(_sh_retry "cat /proc/meminfo")"
    local total_kb; total_kb="$(echo "${meminfo}" | awk '/^MemTotal/{print $2}')"
    local avail_kb; avail_kb="$(echo "${meminfo}" | awk '/^MemAvailable/{print $2}')"
    local total_mb=$(( ${total_kb:-0} / 1024 ))
    local avail_mb=$(( ${avail_kb:-0} / 1024 ))
    local used_mb=$(( total_mb - avail_mb ))
    local pct=$(( used_mb * 100 / (total_mb > 0 ? total_mb : 1) ))

    printf "  ${WHITE}RAM:${C0} %dMB/%dMB użyte (%d%%)\n" "${used_mb}" "${total_mb}" "${pct}"
    [[ ${pct} -gt 80 ]] && warn "Krytyczne zużycie RAM — optymalizacja bardzo potrzebna!"

    printf "\n"
    printf "  ${YELLOW}Wybierz akcję:${C0}\n"
    printf "  ${CYAN}1${C0}) Wyczyść cache aplikacji (pm trim-caches)\n"
    printf "  ${CYAN}2${C0}) Wyłącz Phantom Process Monitor\n"
    printf "      Uniemożliwia Androidowi 16 zabijanie potrzebnych procesów\n"
    printf "  ${CYAN}3${C0}) Ogranicz procesy tła (limit=4)\n"
    printf "  ${CYAN}4${C0}) Wyczyść logi bez zatrzymywania logd ${GREEN}(bezpieczne)${C0}\n"
    printf "  ${CYAN}5${C0}) Wszystkie powyższe naraz\n"
    printf "  ${CYAN}0${C0}) Anuluj\n\n"
    read -r -p "  > " choice

    local do_all=false
    [[ "${choice}" == "5" ]] && do_all=true

    if [[ "${choice}" == "1" || "${do_all}" == "true" ]]; then
        info "Czyszczenie cache aplikacji..."
        # pm trim-caches 0 = wyczyść wszystko (bez minimalnego progu)
        _sh_retry "pm trim-caches 0" || \
        _sh_retry "pm trim-caches 2147483647" || \
            warn "trim-caches nie powiodło się — brak uprawnień?"
        ok "Cache wyczyszczone"
    fi

    if [[ "${choice}" == "2" || "${do_all}" == "true" ]]; then
        # Na Android 12+ (SDK 31+): monitor_phantom_procs
        # false = Android NIE zabija procesów tła po przekroczeniu limitu
        # To ważne dla zdrowia, snu i innych czujników działających w tle!
        _sh_retry "settings put global monitor_phantom_procs false" || true
        ok "Phantom Process Monitor wyłączony"
        info "Procesy zdrowia/snu nie będą już zabijane przez Androida"
    fi

    if [[ "${choice}" == "3" || "${do_all}" == "true" ]]; then
        # Ogranicz do 4 procesów tła (domyślnie -1 = bez limitu)
        _sh_retry "settings put global background_process_limit 4" || true
        ok "Limit procesów tła: 4"
    fi

    if [[ "${choice}" == "4" || "${do_all}" == "true" ]]; then
        # Wyczyść bufor logcat BEZ zatrzymywania logd (w odróżnieniu od niebezpiecznego 'stop logd')
        _sh "logcat -c" || true
        # Ogranicz rozmiar bufora logcat (domyślnie 256KB * 3 = 768KB)
        _sh_retry "setprop logd.buffer.size 64K" || true
        ok "Bufor logcat wyczyszczony (logd DZIAŁA normalnie)"
        warn "NIE używaj 'stop logd' — to destabilizuje system!"
    fi
}

# ═══════════════════════════════════════════════════════════════════════════════
# §9  FIX 5: KOMPILACJA ART — krytyczne po aktualizacji One UI 8.0
# ═══════════════════════════════════════════════════════════════════════════════
#
#  Po OTA aktualizacji aplikacje są tylko "verified" (szybki install)
#  ale nie skompilowane do kodu maszynowego. Pierwsze uruchomienia lagują.
#  Rozwiązanie: wymuś kompilację speed-profile dla wszystkich aplikacji
#

_fix_art() {
    hdr "Fix 5: Kompilacja ART (speed-profile)"
    info "SDK: ${DEVICE_SDK:-?}"
    info "Czas: 2-10 minut w zależności od liczby aplikacji"
    warn "Zegarek musi być podłączony przez cały czas!"

    printf "\n"
    printf "  ${YELLOW}Wybierz opcję:${C0}\n"
    printf "  ${CYAN}1${C0}) Kompilacja speed-profile (wszystkie app) ${YELLOW}~5 min${C0}\n"
    printf "      Najlepsza opcja po aktualizacji OTA\n"
    printf "  ${CYAN}2${C0}) Kompilacja speed (szybsza kompilacja, większy plik) ${YELLOW}~8 min${C0}\n"
    printf "  ${CYAN}3${C0}) Verify only (szybkie, bez kompilacji)\n"
    printf "  ${CYAN}4${C0}) Reset profili (wymuś ponowną naukę) ${RED}zrestartuje optymalizacje${C0}\n"
    printf "  ${CYAN}0${C0}) Anuluj\n\n"
    read -r -p "  > " choice

    local mode
    case "${choice}" in
        1) mode="speed-profile" ;;
        2) mode="speed" ;;
        3) mode="verify" ;;
        4)
            info "Reset profili ART..."
            _sh "cmd package compile --reset -a" || \
            _sh "pm compile --reset -a" || true
            ok "Profile ART zresetowane"
            info "Aplikacje zostaną ponownie skompilowane przy pierwszym uruchomieniu"
            return ;;
        0) return ;;
        *) warn "Nieznana opcja"; return ;;
    esac

    info "Uruchamiam pm compile -m ${mode} -a ..."
    info "Postęp jest pokazywany w logach zegarku — tu wyświetlę timelapse"

    # Pokaż postęp (ADB kompiluje w tle, nie zwraca realtime progress)
    local start_time; start_time="${SECONDS}"
    printf "\n"

    # Uruchom kompilację w tle na urządzeniu
    # Android 12+ (SDK 31+): pm compile -m MODE -a
    # Android 13+ (SDK 33+): cmd package compile -m MODE --all (alternatywna forma)
    local sdk="${DEVICE_SDK:-31}"

    if [[ "${sdk}" -ge 33 ]]; then
        # Preferowana forma dla SDK 33+
        timeout 600 adb -s "${DEVICE}" shell "pm compile -m ${mode} -a" 2>/dev/null &
    else
        timeout 600 adb -s "${DEVICE}" shell "cmd package compile -m ${mode} --all" 2>/dev/null &
    fi
    local compile_pid=$!

    # Animacja oczekiwania
    local dots=0
    while kill -0 ${compile_pid} 2>/dev/null; do
        dots=$(( (dots + 1) % 4 ))
        printf "\r  ${CYAN}Kompilowanie ART${C0}%s   " "$(printf '%.0s.' $(seq 1 $dots))"
        sleep 2
    done
    wait ${compile_pid} && rc=0 || rc=$?
    printf "\n"

    local elapsed=$(( SECONDS - start_time ))
    if [[ ${rc} -eq 0 ]]; then
        ok "Kompilacja ART ukończona (${elapsed}s)"
        info "Efekt: pierwsze uruchomienia aplikacji znacznie szybsze"
        # Opcjonalnie uruchom bg-dexopt (jeśli dostępne)
        _sh "cmd package bg-dexopt-job" 2>/dev/null || true
    else
        warn "Kompilacja ART zakończona z błędem (${rc}) lub timeout"
        warn "Spróbuj ponownie gdy zegarek jest w pełni naładowany"
    fi
}

# ═══════════════════════════════════════════════════════════════════════════════
# §10  FIX 6: PAKIET KOMPLEKSOWY — wszystkie optymalizacje naraz
# ═══════════════════════════════════════════════════════════════════════════════

_fix_all() {
    hdr "Pakiet Kompleksowy — One UI 8.0 Post-Update Fix"
    _backup_settings

    printf "\n${YELLOW}${BOLD}  UWAGA: Zostaną zastosowane wszystkie optymalizacje.${C0}\n"
    printf "  Backup ustawień: %s\n\n" "${BACKUP_FILE}"
    read -r -p "  Kontynuować? [t/N] " conf
    [[ "${conf,,}" != "t" ]] && { info "Anulowano."; return; }

    local step=0 total=12

    _progress "Animacje 0.5x" $(( ++step * 100 / total ))
    _sh_retry "settings put global window_animation_scale 0.5"     || true
    _sh_retry "settings put global transition_animation_scale 0.5" || true
    _sh_retry "settings put global animator_duration_scale 0.5"    || true
    printf "\n"

    _progress "Wyłączam AOD" $(( ++step * 100 / total ))
    _sh_retry "settings put secure doze_always_on 0"               || true
    _sh_retry "settings put secure doze_enabled 0"                 || true
    printf "\n"

    _progress "SF phase offset" $(( ++step * 100 / total ))
    _sh_retry "setprop debug.sf.phase_offset_ns 1000000"           || true
    _sh_retry "setprop debug.sf.early_phase_offset_ns 500000"      || true
    _sh_retry "setprop debug.app.phase_offset_ns 1000000"          || true
    _sh_retry "setprop debug.hwui.profile false"                   || true
    printf "\n"

    _progress "HW Render Thread" $(( ++step * 100 / total ))
    _sh_retry "settings put global high_priority_render_thread 1"  || true
    printf "\n"

    _progress "Phantom procs" $(( ++step * 100 / total ))
    _sh_retry "settings put global monitor_phantom_procs false"    || true
    printf "\n"

    _progress "Bg process limit" $(( ++step * 100 / total ))
    _sh_retry "settings put global background_process_limit 4"     || true
    printf "\n"

    _progress "Trim app caches" $(( ++step * 100 / total ))
    _sh_retry "pm trim-caches 0"                                   || true
    printf "\n"

    _progress "Logcat buffer" $(( ++step * 100 / total ))
    _sh "logcat -c"                                                 || true
    _sh_retry "setprop logd.buffer.size 64K"                       || true
    printf "\n"

    # Exynos W920: Cortex-A55 scheduler tweaks
    _progress "CPU scheduler A55" $(( ++step * 100 / total ))
    _sh_retry "setprop debug.sys.cpufreq.scaling_governor performance" || true
    _sh "echo schedutil > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" 2>/dev/null || true
    printf "\n"

    # Dalvik heap — W920 ma 1.5GB, optymalny heap
    _progress "Dalvik VM heap" $(( ++step * 100 / total ))
    _sh_retry "setprop dalvik.vm.heaptargetutilization 0.75"       || true
    _sh_retry "setprop dalvik.vm.heapmaxfree 8m"                   || true
    printf "\n"

    # Wyczyść cache Dalvik (przebudowane przez ART)
    _progress "VM cache drop" $(( ++step * 100 / total ))
    _sh "sync && echo 3 > /proc/sys/vm/drop_caches" 2>/dev/null   || true
    printf "\n"

    _progress "Weryfikacja" $(( ++step * 100 / total ))
    sleep 1
    printf "\n"

    printf "\n"
    ok "Pakiet kompleksowy zastosowany"
    ok "Zalecany restart zegarka: Trzymaj przycisk boczny → Restart"
    info "Jeśli po restarcie nadal lagi → uruchom Fix 5 (Kompilacja ART)"
    info "Backup: ${BACKUP_FILE}"
}

# ═══════════════════════════════════════════════════════════════════════════════
# §11  PRZYWRACANIE USTAWIEŃ
# ═══════════════════════════════════════════════════════════════════════════════

_restore() {
    hdr "Przywracanie ustawień"

    # Lista backupów
    local backups=()
    while IFS= read -r -d '' f; do
        backups+=("${f}")
    done < <(find "${LOG_DIR}" -name "settings_backup_*.txt" -print0 2>/dev/null | sort -z)

    if [[ ${#backups[@]} -eq 0 ]]; then
        warn "Brak plików backup w ${LOG_DIR}"
        info "Przywracam wartości fabryczne OEM..."

        # Fabryczne wartości One UI 8.0
        _sh_retry "settings put global window_animation_scale 1.0"     || true
        _sh_retry "settings put global transition_animation_scale 1.0" || true
        _sh_retry "settings put global animator_duration_scale 1.0"    || true
        _sh_retry "settings put secure doze_always_on 1"               || true
        _sh_retry "settings put secure doze_enabled 1"                 || true
        _sh_retry "settings put global monitor_phantom_procs true"     || true
        _sh_retry "settings put global background_process_limit -1"    || true
        _sh_retry "settings delete global high_priority_render_thread" || true
        # Przywróć HW overlays
        _sh "service call SurfaceFlinger 1008 i32 0"                   || true
        ok "Przywrócono ustawienia fabryczne OEM"
        return
    fi

    printf "\n  Dostępne backupy:\n"
    for i in "${!backups[@]}"; do
        printf "  ${CYAN}%d${C0}) %s\n" "$((i+1))" "$(basename "${backups[$i]}")"
    done
    printf "  ${CYAN}0${C0}) Anuluj\n\n"
    read -r -p "  Wybierz backup > " sel

    [[ "${sel}" == "0" ]] && return
    local idx=$(( sel - 1 ))
    if [[ ${idx} -lt 0 || ${idx} -ge ${#backups[@]} ]]; then
        warn "Nieprawidłowy wybór"; return
    fi

    local bfile="${backups[$idx]}"
    info "Przywracam z: $(basename "${bfile}")"

    local restored=0 failed=0
    while IFS= read -r line; do
        [[ "${line}" == RESTORE:* ]] || continue
        local rest="${line#RESTORE:}"
        local ns="${rest%%:*}"
        local kv="${rest#*:}"
        local key="${kv%%=*}"
        local val="${kv#*=}"

        if [[ "${val}" == "null" ]]; then
            _sh_retry "settings delete ${ns} ${key}" 2>/dev/null && \
                (( restored++ )) || (( failed++ ))
        else
            _sh_retry "settings put ${ns} ${key} ${val}" 2>/dev/null && \
                (( restored++ )) || (( failed++ ))
        fi
    done < "${bfile}"

    ok "Przywrócono: ${restored} ustawień (błędy: ${failed})"
}

# ═══════════════════════════════════════════════════════════════════════════════
# §12  DIAGNOSTYKA — zebrane raporty użytkowników
# ═══════════════════════════════════════════════════════════════════════════════
#
#  NAPRAWIONE błędy oryginału:
#    · top -b -n 1 -m 10  →  Toybox nie ma -b ani -m  →  używamy top -n 1 -d 1
#    · dumpsys SurfaceFlinger --latency  →  flaga --latency nieobsługiwana  →  bez flagi
#    · brak obsługi uprawnień zapisu do pliku wynikowego
#

_run_diagnostics() {
    hdr "Diagnostyka systemu (WearOS 6.0 / Toybox)"

    local out_dir="${LOG_DIR}/diag_$(date +%Y%m%d_%H%M%S)"
    mkdir -p "${out_dir}"
    info "Zapisuję do: ${out_dir}/"

    local step=0 total=7

    # 1. CPU — Toybox top: brak -b (batch) i -m (max processes)
    # Prawidłowa składnia: top -n ITERATIONS -d DELAY
    _progress "CPU Top 15" $(( ++step * 100 / total ))
    _sh_retry "top -n 1 -d 1" > "${out_dir}/cpu_top.txt" 2>&1 || \
        _sh_retry "top -n 1"   > "${out_dir}/cpu_top.txt" 2>&1 || \
        _sh_retry "ps -A"      > "${out_dir}/cpu_top.txt" 2>&1
    printf "\n"

    # 2. SurfaceFlinger — bez nieistniejącej flagi --latency
    _progress "SurfaceFlinger" $(( ++step * 100 / total ))
    _sh_retry "dumpsys SurfaceFlinger" > "${out_dir}/sf_dump.txt" 2>&1 &
    sleep 3; kill %% 2>/dev/null || true; wait 2>/dev/null
    printf "\n"

    # 3. GPU frame info
    _progress "Frame timing (gfxinfo)" $(( ++step * 100 / total ))
    _sh_retry "dumpsys gfxinfo"                > "${out_dir}/gfx_info.txt" 2>&1 || true
    printf "\n"

    # 4. Pamięć
    _progress "Analiza RAM" $(( ++step * 100 / total ))
    {
        echo "=== dumpsys meminfo ==="
        _sh_retry "dumpsys meminfo"
        echo ""
        echo "=== /proc/meminfo ==="
        _sh_retry "cat /proc/meminfo"
        echo ""
        echo "=== ZRAM ==="
        _sh_retry "cat /proc/swaps" || echo "brak swap/ZRAM"
    } > "${out_dir}/mem_dump.txt" 2>&1
    printf "\n"

    # 5. Thermal / temperatura
    _progress "Temperatura (Exynos W920)" $(( ++step * 100 / total ))
    {
        echo "=== Thermal zones ==="
        for zone in /sys/class/thermal/thermal_zone*/temp; do
            local name; name="$(cat "$(dirname "${zone}")/type" 2>/dev/null || echo '?')"
            local temp; temp="$(cat "${zone}" 2>/dev/null || echo '?')"
            printf "%-30s %s\n" "${name}" "${temp}"
        done 2>/dev/null || _sh_retry "cat /sys/class/thermal/thermal_zone*/temp"
    } > "${out_dir}/thermal.txt" 2>&1
    printf "\n"

    # 6. Logi systemowe — błędy i ostrzeżenia (WearOS ma mało RAMu → ograniczamy)
    _progress "Logcat (błędy/warningi)" $(( ++step * 100 / total ))
    # Użyj timeout żeby nie czekać na pusty bufor
    timeout 10 adb -s "${DEVICE}" logcat -d -v brief "*:W" 2>/dev/null \
        > "${out_dir}/system_logs.txt" || true
    # Filtruj znane One UI 8 problemy
    grep -E "SurfaceFlinger|AOD|doze|lag|drop|jank|render|W920|Exynos" \
        "${out_dir}/system_logs.txt" > "${out_dir}/filtered_logs.txt" 2>/dev/null || true
    printf "\n"

    # 7. Właściwości diagnostyczne
    _progress "System props" $(( ++step * 100 / total ))
    {
        echo "=== Build & Hardware ==="
        _sh_retry "getprop ro.product.model"
        _sh_retry "getprop ro.build.display.id"
        _sh_retry "getprop ro.build.version.release"
        _sh_retry "getprop ro.build.version.sdk"
        _sh_retry "getprop ro.hardware"
        echo ""
        echo "=== Performance Props ==="
        for prop in \
            debug.sf.phase_offset_ns \
            debug.hwui.profile \
            dalvik.vm.heapsize \
            dalvik.vm.heaptargetutilization; do
            printf "%-45s = %s\n" "${prop}" "$(_sh_retry "getprop ${prop}")"
        done
        echo ""
        echo "=== Settings ==="
        for s in \
            "global window_animation_scale" \
            "global transition_animation_scale" \
            "secure doze_always_on" \
            "global monitor_phantom_procs"; do
            local ns="${s%% *}"; local k="${s##* }"
            printf "%-45s = %s\n" "${s}" "$(_sh_retry "settings get ${ns} ${k}")"
        done
    } > "${out_dir}/props.txt" 2>&1
    printf "\n"

    # Generuj raport zbiorczy
    {
        echo "=== GW4 Diagnostic Report ==="
        echo "Data: $(date)"
        echo "Urządzenie: ${DEVICE_MODEL} | FW: ${DEVICE_FW}"
        echo ""
        echo "--- RAM Summary ---"
        grep -E "^Mem|^MemAvailable" "${out_dir}/mem_dump.txt" | head -5
        echo ""
        echo "--- Janky Frames (SurfaceFlinger) ---"
        grep -i "janky\|total frames\|missed vsync" "${out_dir}/gfx_info.txt" | head -10
        echo ""
        echo "--- Filtered Error Logs ---"
        head -30 "${out_dir}/filtered_logs.txt" 2>/dev/null || echo "(brak pasujących wpisów)"
    } > "${out_dir}/RAPORT_ZBIORCZY.txt"

    printf "\n"
    ok "Diagnostyka zakończona"
    ok "Pliki: ${out_dir}/"
    printf "\n  ${YELLOW}Pliki do udostępnienia:${C0}\n"
    for f in cpu_top.txt mem_dump.txt filtered_logs.txt RAPORT_ZBIORCZY.txt; do
        printf "  → %s\n" "${out_dir}/${f}"
    done
    printf "\n  ${CYAN}Wyślij RAPORT_ZBIORCZY.txt gdy zgłaszasz problem.${C0}\n\n"
}

# ═══════════════════════════════════════════════════════════════════════════════
# §13  INSTRUKCJA KONFIGURACJI
# ═══════════════════════════════════════════════════════════════════════════════

_show_setup_guide() {
    clear
    printf "${CYAN}${BOLD}"
    printf "  ╔══════════════════════════════════════════════════════════════╗\n"
    printf "  ║  Instrukcja: Pierwsze połączenie ADB z Galaxy Watch 4       ║\n"
    printf "  ╚══════════════════════════════════════════════════════════════╝\n"
    printf "${C0}\n"
    printf "${BOLD}  KROK 1: Włącz Opcje Programisty na zegarku${C0}\n"
    printf "    1. Ustawienia → System → Informacje o zegarku\n"
    printf "    2. Kliknij ${YELLOW}\"Numer kompilacji\" 7 razy${C0}\n"
    printf "       (pojawi się: \"Opcje programisty włączone\")\n\n"
    printf "${BOLD}  KROK 2: Włącz debugowanie Wi-Fi${C0}\n"
    printf "    1. Ustawienia → Opcje programisty\n"
    printf "    2. Włącz ${YELLOW}\"Debugowanie przez Wi-Fi\"${C0}\n"
    printf "    3. Zegarek wyświetli adres IP i port (np. 192.168.1.X:5555)\n"
    printf "       ${RED}ZANOTUJ ten adres!${C0}\n\n"
    printf "${BOLD}  KROK 3: Zatwierdź klucz RSA${C0}\n"
    printf "    1. Na PC uruchom: ${CYAN}adb connect TWOJE_IP:5555${C0}\n"
    printf "    2. Na zegarku pojawi się komunikat ${YELLOW}\"Czy zezwolić?\"${C0}\n"
    printf "    3. Kliknij ${GREEN}Akceptuj${C0}\n\n"
    printf "${BOLD}  KROK 4: Weryfikacja${C0}\n"
    printf "    ${CYAN}adb devices${C0}  → powinno pokazać urządzenie ze statusem \"device\"\n\n"
    printf "  ${DIM}Uwagi:\n"
    printf "  • Zegarek i PC muszą być w tej samej sieci Wi-Fi\n"
    printf "  • Adres IP po ponownym podłączeniu do Wi-Fi może się zmienić\n"
    printf "  • Jeśli zegarek zasypia, połączenie ADB może zostać zerwane\n"
    printf "    (skrypt automatycznie próbuje się reconnectować)\n"
    printf "${C0}\n"
    read -r -p "  Naciśnij Enter aby wrócić do menu..."
}

# ═══════════════════════════════════════════════════════════════════════════════
# §14  BANNER I MENU GŁÓWNE
# ═══════════════════════════════════════════════════════════════════════════════

_print_banner() {
    clear
    printf "${CYAN}${BOLD}"
    printf "  ╔══════════════════════════════════════════════════════════════════╗\n"
    printf "  ║  %-66s ║\n" "${SCRIPT_NAME}  v${VERSION}"
    printf "  ║  %-66s ║\n" "Samsung SM-R870 · Exynos W920 · One UI 8.0 / WearOS 6.0"
    if [[ -n "${DEVICE}" ]]; then
        printf "  ╠══════════════════════════════════════════════════════════════════╣\n"
        printf "  ║  %-66s ║\n" "Połączono: ${DEVICE}  |  ${DEVICE_MODEL:-?}"
        printf "  ║  %-66s ║\n" "Firmware: ${DEVICE_FW:-?}  |  Android SDK ${DEVICE_SDK:-?}"
    fi
    printf "  ╚══════════════════════════════════════════════════════════════════╝\n"
    printf "${C0}\n"
}

_print_menu() {
    printf "  ${WHITE}${BOLD}─── OPTYMALIZACJE ─────────────────────────────────────────────────${C0}\n"
    printf "  ${CYAN}1${C0}) Animacje (0.5x/0x/przywróć)        ${DIM}~2s  • zero ryzyka${C0}\n"
    printf "  ${CYAN}2${C0}) AOD — Always-On Display             ${DIM}~2s  • główny fix lagów${C0}\n"
    printf "  ${CYAN}3${C0}) SurfaceFlinger (vsync/phase offset) ${DIM}~3s  • renderowanie${C0}\n"
    printf "  ${CYAN}4${C0}) Pamięć, procesy tła, cache          ${DIM}~5s  • RAM / phantom procs${C0}\n"
    printf "  ${CYAN}5${C0}) Kompilacja ART speed-profile        ${DIM}~5min • po aktualizacji OTA${C0}\n"
    printf "  ${CYAN}6${C0}) ${GREEN}PAKIET KOMPLEKSOWY${C0} (wszystko naraz)  ${YELLOW}~8min • zalecany${C0}\n"
    printf "\n"
    printf "  ${WHITE}${BOLD}─── NARZĘDZIA ─────────────────────────────────────────────────────${C0}\n"
    printf "  ${CYAN}D${C0}) Diagnostyka systemu (zbierz raporty)\n"
    printf "  ${CYAN}R${C0}) Przywróć ustawienia (z backupu lub OEM)\n"
    printf "  ${CYAN}?${C0}) Instrukcja: jak połączyć zegarek przez ADB\n"
    printf "  ${CYAN}Q${C0}) Wyjście\n\n"
}

# ═══════════════════════════════════════════════════════════════════════════════
# §15  PĘTLA GŁÓWNA
# ═══════════════════════════════════════════════════════════════════════════════

_loop() {
    while true; do
        _print_banner
        _print_menu
        read -r -p "  ${CYAN}${BOLD}Wybierz opcję${C0} > " opt

        case "${opt^^}" in
            1) _fix_animations ;;
            2) _fix_aod ;;
            3) _fix_surfaceflinger ;;
            4) _fix_memory ;;
            5) _fix_art ;;
            6) _fix_all ;;
            D) _run_diagnostics ;;
            R) _restore ;;
            '?'|H) _show_setup_guide ;;
            Q) ok "Do widzenia!"; exit 0 ;;
            '') continue ;;
            *)  warn "Nieznana opcja: '${opt}'" ;;
        esac

        printf "\n"
        read -r -p "  Naciśnij Enter aby wrócić do menu..."
    done
}

# ═══════════════════════════════════════════════════════════════════════════════
# §16  MAIN
# ═══════════════════════════════════════════════════════════════════════════════

main() {
    _init

    _print_banner

    printf "  ${CYAN}Log sesji:${C0} ${LOG_FILE}\n"
    printf "  ${DIM}Wersja: %s | ADB: %s${C0}\n\n" \
        "${VERSION}" "$(adb version 2>/dev/null | head -1 | awk '{print $NF}' || echo '?')"

    _detect_device
    _loop
}

main "$@"
